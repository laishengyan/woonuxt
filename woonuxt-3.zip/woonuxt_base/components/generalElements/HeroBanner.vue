<template>
  <div class="mx-auto max-w-[1200px] h-[7.03rem] md:h-[360px] lg:mt-[10px]">
    <Swiper :duration="5000" autoplay :showNav="false">
      <SwiperItem>
        <img src="/icons/lunbo_1.webp" alt="" loading="lazy" class="h-[100%]" width="100%" height="100%">
      </SwiperItem>
      <SwiperItem>
        <img src="/icons/lunbo_1.webp" alt="" loading="lazy" class="h-[100%]" width="100%" height="100%">
      </SwiperItem>
      <SwiperItem>
        <img src="/icons/lunbo_1.webp" alt="" loading="lazy" class="h-[100%]" width="100%" height="100%">
      </SwiperItem>
    </Swiper>
  </div>
</template>